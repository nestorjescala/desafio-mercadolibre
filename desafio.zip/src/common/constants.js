export const ENDPOINTS = {
  BASE: 'http://localhost:9000/'
};